import yt_dlp

url_lagu = input("masukan url lagu >> ")
judul_lagu = input("masukan judul lagu >> ")

ydl_opts = {
    'format': 'bestaudio/best',
    'outtmpl': f"{judul_lagu}.%(ext)s",
    'postprocessors': [{
        'key': 'FFmpegExtractAudio',
        'preferredcodec': 'mp3',  
        'preferredquality': '192',
    }],
}

print("Memulai proses download... Tunggu sebentar ya.")

try:
    with yt_dlp.YoutubeDL(ydl_opts) as ydl:
        ydl.download([url_lagu])
    print(f"Mantap! Lagu berhasil didownload dan dikonversi menjadi {judul_lagu}.mp3.")
except Exception as e:
    print(f"Yah, terjadi error: {e}")